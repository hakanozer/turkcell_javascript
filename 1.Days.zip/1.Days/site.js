//alert("site.js Alert");
/*
Commnet line
Commnet line
*/


// String 
// let -> yeni stil
// var -> eski stil
let name = "Ali Bilmem"
//alert(name)
var name1 = "Ali Bilmem"
name = "Serkan";
let city = 'İstanbul';

// int
let age = 40;
let number;
number = 30;
if (number == undefined) {
    alert("num empty");
}

// string change int
let statu = "online";
console.log("Statu : " + (statu + 10) )
statu = 30;
console.log("Statu : " + (statu + 10) )
//console.log( ""+ statu + 10 )


// final -> const
// içerisini sabit olarak kullanmak istediğimizde
const num1 = 50;
//num1 = 40;
const action = 1 / 0; // Infinity
console.log( "action : "+ action )

// Nan
const nanVariable = Number / 2;
console.log( "nanVariable : "+ nanVariable )

const concat = "sonuç : " + " num1 : " + num1
console.log( "concat : "+ concat )

// null
//let numVariable; // ram
let numVariable = null; // ram -> null
//numVariable = "Hello Javascript";
//console.log("num : " + numVariable.length );


// type casting
let st = '30';
let intCast = parseInt(st);
const sum = intCast + 10;
console.log("sum : " + sum )

// int to String
let num2 = 50;
let intCastString = ""+num2;
console.log("intCastString : " + (intCastString + 40 ) )


// String typeof
console.log( typeof "ali" )
console.log( typeof 10 )
console.log( typeof 10.5 )
console.log( typeof true )
console.log( typeof Math )
console.log( typeof null )
console.log( typeof alert )
const type = typeof num2
if (type == number) {

}


// if control
// == -> değer olarak eşit mi ?
// === -> değer ve tür olarak eşir mi ?
const sta = "ali";
const stb = 20;
if( sta === stb ) { // ===
    //alert("st1 == ali")
}else {
    //alert("st1 != ali")
}

const key = "cik";
switch (key) {

    case "cik":
        // action
        //alert("fail");
    break;

    case "evdekal":
        //alert("success");
    break;

    default:
        //alert("Defult");
    break;
}


// arrays
const st2 = "Ali Bilmem";
let arr = ["Ali", 30, true, 10.5]
arr.push("statu") // new item add arr
console.log("count : " + arr.length )
arr.forEach( (item, index) => {
    console.log( "index : " + index + " item : " + item)
});

console.log("======================")
for (let index = 0; index < 10; index++) {

    if (index == 0) {
        continue; // döngüdeki bu adımı atla
    }

    if (index == 2) {
        break; // döngüyü bitir
    }

    if ( arr[index] !=  undefined) {
        console.log("index : " + arr[index])
    }
    
}

console.log("======================")

// object item
let obj1 = new Object()
let obj = { "name": "Ali", "age": 40 }
// new item
obj["statu"] = true
obj["role"] = "user"
console.log( JSON.stringify(obj) )
Object.keys(obj).map( (key) => {
    console.log('key :  ' + " " + key + ' value : ' + obj[key] )
})


console.log("======================")
// arr in object item
let arr1 = []
for (let index = 0; index < 10; index++) {
    const userObject = {
        "name": "Ali" +index,
        "age": index,
        "statu": true
    }
    arr1.push(userObject);
}
console.log("arr1 : " + JSON.stringify(arr1))


// function
function sumFnc ( a, b ) {
    const sm = a + b;
    console.log('sumFnc', sm);
   return sm;
}
const sm = sumFnc(40,60);

// no paramter and no
function noParameter() {
    alert("noParameter call");
}

function login() {
    const mail = document.getElementById("email").value;
    const pass = document.getElementById("password").value;
    if (mail == "ali@ali.com" && pass == "12345") {
        // user login
    }else {
        alert("Username of pass fail!")
    }
}

/*
const formSend = document.getElementById("sendForm");
formSend.onsubmit( () => {
    console.log('formSend', "form sending")
})
*/
function fncSubmit () {
    const mail = document.getElementById("email1").value;
    const pass = document.getElementById("pass1").value;

    if (mail == "" || pass == "") {
        // form send break
        alert("User name or pass fail!")
        return false;
    }else {
        // form send success
        console.log('login Statu', "Success")
    }

}

/*
fncAlt = () => {
    alert("merhaba ecma");
}
fncAlt();
*/


// object new instance
const utilObj = new Util("İstanbul");
utilObj.write("Güzel");


// sum method call
function sumObj () {
    const n1 = document.getElementById("num1").value
    const n2 = document.getElementById("num2").value

    const sm = utilObj.sum(n1, n2);
    console.log('sm', sm)
    document.getElementById("total").innerHTML = "<h1 style='color:red'>Sum : " + sm + "</h1>";
}