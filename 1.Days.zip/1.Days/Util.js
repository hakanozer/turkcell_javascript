class Util {
    
    // no parameter
    /*
    constructor() {
        console.log('constructor', "call");
    }
    */

    data = "";

    // parameter
    constructor(data) {
        console.log('constructor data', data )
        this.data = data;
    }

    // () fnc parameter
    write = ( addString ) => {
        // fnc bodys
        const st = addString + " " + this.data;
        console.log('st', st);
    }


    sum = ( num1, num2 ) => {
        return parseInt(num1) + parseInt(num2);
    }


}