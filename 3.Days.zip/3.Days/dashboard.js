$(document).ready(function () {

    let bilgiler = []
    const userLocal = localStorage.getItem("user");
    if(userLocal) {
        const json = JSON.parse(userLocal);
        const nameSurname = json.userName + " " + json.userSurname 
        $("#userName").html(nameSurname).hide(); // değeri eşitle sonra kaldır.
        $("#userName").slideDown() // animasyonlu getir.
    }


    // products data
    const url = "https://www.jsonbulut.com/json/product.php"
    const data = {
        ref: "5380f5dbcc3b1021f93ab24c3a1aac24",
        start: "0"
    }
    // ajax call
    $.ajax({
        type: "get",
        url: url,
        data: data,
        dataType: "json",
        success: function (res) {
            bilgiler = res.Products[0].bilgiler
            fncProGenerator(bilgiler)
        },
        error: function (request, status, error) { 
            console.log('error', JSON.stringify(status));
        }
    });


    // product generator
    fncProGenerator = ( bilgiler ) => {
        //console.log('bilgiler', JSON.stringify(bilgiler))
        let html = "";
        bilgiler.forEach( (item, index)  => {
            html += fncProductItemGenerator(item, index)
        });
        $('#productList').html(html)

        // product hover
        $("div#card").hover(function () {
                // over;
                $(this).css("border-color", "red");
            }, function () {
                // out
                //console.log('card', "out")
                $(this).css("border-color", "rgba(0,0,0,.125)");
            }
        );

    }


    // product item generator
    fncProductItemGenerator = (item, index) => {
        const returnItem = `
        <div class="col-sm-4">
            <div id="card" class="card" style='height: 530px; margin-bottom: 20px; ' >
                <img height="270" src="`+item.images[0].normal+`" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">`+item.productName+`</h5>
                    <p class="card-text">`+item.brief+`</p>
                    <a onclick="fncDetailItem(`+index+`)" href="#" class="btn btn-primary" style="position: absolute;bottom: 0;margin-bottom: 18px;">Go somewhere</a>
                </div>
            </div>
        </div>`
        return returnItem;
    }

    // product item goto Detail
    fncDetailItem  = (index) => {
        //console.log('detail item', JSON.stringify(bilgiler[index]))
        localStorage.setItem("detail", JSON.stringify(bilgiler[index]) )
        window.location.href = "detail.html";
    }


});