$(document).ready(function () {
    
    const item = localStorage.getItem("detail");
    if (item) {

        const itm = JSON.parse(item);
        $('#productName').html(itm.productName);
        $('#price').html(itm.price);
        $('#description').html(itm.description);

        let html = "";
        itm.images.forEach( (imgItem, index) => {
            const active = index == 0 ? 'active ' : '';
            const htmlItem = `
            <div class="carousel-item `+active+`" data-slide-to="`+index+`" data-interval="1000">
                <img src="`+imgItem.normal+`" class="d-block w-100" alt="...">
            </div>
            `
            html += htmlItem
        });
        $('#slider').html(html)


    }

    
    $('.carousel').carousel()
});