    // remember me control!
    const remember = localStorage.getItem("remember");
    if (remember) {
        sessionStorage.setItem("user", remember)
    }
    
    // user session control
    const session = sessionStorage.getItem("user");
    if (session) {
        // session true
    }else {
        window.location.href = "index.html";
    }


    // User Logut 
    function userExit() {

        // confirm
        const answer = confirm("Are you exit ?");
        if (answer) {
            // session remove
            sessionStorage.removeItem("user")
            // session remove all
            sessionStorage.clear();

            // localStorger remove data
            localStorage.removeItem("user")
            localStorage.clear() // all 

            // redirect
            window.location.href = "index.html";
        }


    }