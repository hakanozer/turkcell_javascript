$(document).ready(function () {
    
    const userLocal = localStorage.getItem("user");
    if(userLocal) {
        const json = JSON.parse(userLocal);
        const nameSurname = json.userName + " " + json.userSurname 
        $("#userName").html(nameSurname).hide(); // değeri eşitle sonra kaldır.
        $("#userName").slideDown() // animasyonlu getir.
    }

});