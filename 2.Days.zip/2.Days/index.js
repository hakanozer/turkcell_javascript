$(document).ready(function () {

    send = () => {
        alert("send btn click");
    }

    sendFnc = function () {
        alert("send function btn click");
    }

    // id selector
    /*
    $("#btnSend").click( function() {

    })
    */

    // css selector
    /*
    $('.btn-primary').click( function () {
        alert("css selector selected")
    }) 
    */

    // attr selector
    /*
    $('button[type="submit"]').click( function () {
        alert("attr selector selected")
    }) 
    */

    // form submit lis.
    $('#formLogin').submit(function (e) { 
        
        const mail = $('#email').val();
        const pass = $('#pass').val();

        if ( mail == "") {
            $('#email').focus();
            lblSelector("email");
            $('#email').slideToggle(200, function () {
                $('#email').slideToggle(200);
            });
        }else if ( pass == "") {
            $('#pass').focus();
            lblSelector("pass");
            $('#pass').slideToggle(200, function () {
                $('#pass').slideToggle(200);
            });
        }else {

            const url = "https://www.jsonbulut.com/json/userLogin.php";
            const data = {
                ref: "5380f5dbcc3b1021f93ab24c3a1aac24",
                userEmail: mail,
                userPass: pass,
                face: "no"
            }

            $.ajax({
                type: "get",
                url: url,
                data: data,
                dataType: "json",
                success: function (res) {
                    //console.log('res', JSON.stringify(res) );
                    const us = res.user[0]
                    const durum = us.durum
                    if (durum) {
                        // user login success
                        const bilgiler = us.bilgiler
                        // localStorge insert data
                        localStorage.setItem("user", JSON.stringify(bilgiler))
                        window.location.href = "dashboard.html";
                    } else {
                        // user fail data
                        lblSelector("email");
                        lblSelector("pass");
                        $('#email').css("border-color", "red");
                        $('#pass').css("border-color", "red");
                    }
                },
                error: function (request, status, error) { 
                    console.log('error', JSON.stringify(status));
                 }
            });

        }

        return false;
    });

    // label selector text red
    lblSelector = ( name, color = "red" ) => {
        $("#lbl"+name).css("color", color);
        $('#'+name).css("border-color", "#ced4da");
    }

    // txt change lis.
    $('#email').keypress(function (e) { 
        lblSelector("email", "#212529")
    });
    $('#pass').keypress(function (e) { 
        lblSelector("pass", "#212529")
    });


    



})