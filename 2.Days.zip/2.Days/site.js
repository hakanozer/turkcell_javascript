$(document).ready(function () {

    send = () => {
        alert("send btn click");
    }

    sendFnc = function () {
        alert("send function btn click");
    }

    // id selector
    /*
    $("#btnSend").click( function() {

    })
    */

    // css selector
    /*
    $('.btn-primary').click( function () {
        alert("css selector selected")
    }) 
    */

    // attr selector
    /*
    $('button[type="submit"]').click( function () {
        alert("attr selector selected")
    }) 
    */

    // form submit lis.
    $('#formLogin').submit(function (e) { 
        
        const mail = $('#email').val();
        const pass = $('#pass').val();

        if ( mail == "") {
            $('#email').focus();
            lblSelector("email");
            $('#email').slideToggle(200, function () {
                $('#email').slideToggle(200);
            });
        }else if ( pass == "") {
            $('#pass').focus();
            lblSelector("pass");
            $('#pass').slideToggle(200, function () {
                $('#pass').slideToggle(200);
            });
        }else {

        }

        return false;
    });


    // label selector text red
    lblSelector = ( name, color = "red" ) => {
        $("#lbl"+name).css("color", color);
    }

    // txt change lis.
    $('#email').keypress(function (e) { 
        lblSelector("email", "#212529")
    });
    $('#pass').keypress(function (e) { 
        lblSelector("pass", "#212529")
    });


    



})